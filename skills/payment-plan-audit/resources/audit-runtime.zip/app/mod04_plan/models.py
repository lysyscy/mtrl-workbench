MATCH_MATCHED = 'matched'
MATCH_UNMATCHED = 'unmatched'
MATCH_AMBIGUOUS = 'ambiguous'
EDITABLE_COLUMNS = ('pay_date', 'pay_method', 'remark')